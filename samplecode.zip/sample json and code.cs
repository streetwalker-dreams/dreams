//Sample json data in characterTypes.json
//m prefix means max
[
	{  // this is one saved character
		"strength":20,
		"mStrength":31,
		"health":60,
		"mHealth":71,
		"kind":"MELEE",  //< this is the dictionary key
		"title":"Knight",
		"name":"George"
	}
]

// ********************* sample json data manager C#
using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using LitJson;

public class SavedDataManager {
    private static string jsonString;
    private static JsonData roomData;
    private static string BASE_FILE_PATH = "/Resources/savedData/";
    public const string CHARSTATS_FILE = "characterTypes.json";

    // constructor - becasue the functions are static, not sure if this was necessary
    // probably better to make everything non-static and put in a Singleton
    public SavedDataManager(){
    }

    public static Dictionary<string, CharacterStats>  loadCharacterStats(){
		string jsonString = File.ReadAllText(Application.dataPath + BASE_FILE_PATH + CHARSTATS_FILE );
		JsonData c =  JsonMapper.ToObject(jsonString);
		Dictionary<string, CharacterStats> charTypes = new Dictionary<string, CharacterStats>();
		for( int i = 0; i < c.Count; i++ ){
			string cKind = c[i]["kind"].ToString();
			charTypes[cKind] =  new CharacterStats( cKind, c[i]["title"].ToString(), c[i]["name"].ToString(),
			    (int) c[i]["strength"], (int) c[i]["mStrength"], (int) c[i]["health"], (int) c[i]["mHealth"]
            );
		}
		return charTypes;
	}
}

using UnityEngine;
using System.Collections;

// **************************** sample character object
public class CharacterStats {

	/*public const int MELEE = 0;
	public const int MAGIC = 1;
	public const int RANGE = 2;*/

	public int physicalStrength, maxPhysicalStrength;
	public int health, maxHealth;

	public string kind;
	public string title;
	public string name;



	public CharacterStats( string cKind, string cTitle, string cName,
			int strength, int mStrength, int cHealth, int mHealth  ){

		kind = cKind;
		title = cTitle;
		name = cName;
		physicalStrength = strength;
		maxPhysicalStrength = mStrength;
		health = cHealth;
		maxHealth = mHealth;
	}

}

// **********  sample player object that will be created using character status
public class PLAYER {

	/*public const int MELEE = 0;
	public const int MAGIC = 1;
	public const int RANGE = 2;*/

	public int physicalStrength, maxPhysicalStrength;
	public int health, maxHealth;

	public string kind, title, name;
	public int row, col;  // the maze location

	public int facingAngle;


	public PLAYER( CharacterStats cS, LOC cLoc, int cFacingAngle ){
		row = cLoc.row;
		col = cLoc.col;
		facingAngle = cFacingAngle;
		kind = cS.kind;
		title = cS.title;
		name = cS.name;
		physicalStrength = maxPhysicalStrength = Random.Range( cS.physicalStrength, cS.maxPhysicalStrength);
		health = maxHealth = Random.Range( cS.health, cS.maxHealth );
	}

	public void setLoc( LOC c ){
		row = c.row;
		col = c.col;
	}\
}

// ***** in the main program:  create a new player from the saved data
public PLAYER gamePlayer;
public Dictionary<string, CharacterStats> charStats;
charStats = SavedDataManager.loadCharacterStats(); // load the character stats from json file
gamePlayer = new PLAYER( charStats["MELEE"], currLoc, facingAngle ); // pass the dictionary to the Player constructor
